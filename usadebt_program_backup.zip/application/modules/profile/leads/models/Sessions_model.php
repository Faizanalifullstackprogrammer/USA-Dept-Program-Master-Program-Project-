<?php
class Sessions_model extends CI_Model
{
	
	
}
?>
