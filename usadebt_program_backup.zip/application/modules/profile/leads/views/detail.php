<!-- MAIN CONTENT-->
<div class="main-content">
	<div class="section__content section__content--p30">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="overview-wrap">
						<h2 class="title-1"><?php echo $module_title; ?></h2>
						<?php if($this->common_model->is_admin() && $this->input->get('status') == 0): ?>
						<button  class="au-btn au-btn-icon au-btn--green au-btn--small nw_clicks">
							<a  style="color: #fff;" href="<?php echo base_url($module.'/admin/add') ?>"><i class="zmdi zmdi-plus"></i>Add New</a>
						</button>
						<?php endif; ?>
						
					</div>
				</div>
			</div>
			<div class="row row m-t-25">
				<div class="col-md-12">
					<!-- DATA TABLE-->
					<?php 
							if($this->session->flashdata('flash_message'))
							{ ?>
								<div class="sufee-alert alert with-close alert-<?php echo $this->session->flashdata('class'); ?> alert-dismissible fade show">
									 <?php echo $this->session->flashdata('flash_message'); ?> 
									<button type="button" class="close" data-dismiss="alert" aria-label="Close">
										<span aria-hidden="true">×</span>
									</button>
								</div>
								<?php
							}
					?>
					<?php $this->load->view($module.'/filters'); ?>
					
					
					<div class="table-responsive m-b-40">
						<table class="table table-borderless table-data3">
							<thead>
								<tr>
									<th>Lead ID</th>
									<th>Created On</th>
									<th>Product Name</th>
									<th>Assign To</th>
									<!--
									<th>Purpose</th>
									-->
									<th>Status</th>
									<th>No of days</th>
									<th>Replied</th>
									<th>action</th>
								</tr>
							</thead>
							<tbody>
								<?php if($results): ?>
									<?php foreach($results as $result): ?>
										
											<?php $username = $this->common_model->GetSingleValue(USERS_TABLE,'name',array('id' => $result['user_id'])); ?>
											<?php $purpose = $this->common_model->GetSingleValue(PURPOSES_TABLE,'title',array('id' => $result['purpose'])); ?>
											<?php 
												$reply_exists = $this->common_model->checkExists(LEADS_REPLY_TABLE,array('lead_id' => $result['id'] ,'seen' => 0 , 'sender_id <> ' => $this->session->userdata('user_id') ));
												$reply_exists_check = $reply_exists > 0 ? "checked" : "";
											?>
											
											<tr>
												<td><?php echo $result['id']; ?></td>
												<td><?php echo date('d/m/Y h:i a',$result['assigned_on']); ?></td>
												<td><?php echo ucfirst($result['product_name']); ?></td>
												<td><?php echo ucfirst($username); ?></td>
												<!--
												<td><?php echo ucfirst($purpose); ?></td>
												-->
												<td>
													<?php 
														$disable = ""; 
														$status_text = "Open";
														if($result['status'] ==1)
														{
															$disable = "disabled";
															$status_text = "Closed";
														}
														if($result['status'] ==2)
														{
															$status_text = "On Hold";
														}
													?>
													<?php if($this->common_model->is_admin() && $result['status'] <> 1): ?>
															<div class="rs-select2--trans rs-select2--sm">
																<select lead_id="<?php echo $result['id']?>" class="js-select2" name="status">
																	<option <?php echo $disable; ?> value="0" <?php if($result['status'] ==0){ echo "selected"; }; ?> >Open</option>
																	<option <?php echo $disable; ?> value="2" <?php if($result['status'] ==2){ echo "selected"; }; ?> >Hold</option>
																	<option <?php echo $disable; ?> value="1" <?php if($result['status'] ==1){ echo "selected"; }; ?> >Close</option>
																</select>
																<div class="dropDownSelect2"></div>
															</div>
													<?php else: ?>	
														<?php echo ucfirst($status_text); ?>
													<?php endif; ?>	
												</td>
												<td><?php echo $result['activated_for']; ?></td>
											
												<td>
													<label class="au-checkbox">
														<input type="checkbox" <?php echo $reply_exists_check; ?> disabled> 
														<span class="au-checkmark"></span>
													</label>
												</td>
												
												<td>
													<div class="table-data-feature">
														<?php if($this->common_model->is_admin() && $result['status'] <> 1): ?>
														<button class="item edit nw_clicks" data-toggle="tooltip" pid="<?php echo $result['id'] ?>" data-placement="top" title="" data-original-title="Edit">
															<a href="<?php echo base_url($module.'/admin/edit/'.$result['id']); ?>" ><i class="zmdi zmdi-edit"></i></a>
														</button>
														<?php endif; ?>
														
														<button class="item edit nw_clicks" data-toggle="tooltip" pid="<?php echo $result['id'] ?>" data-placement="top" title="" data-original-title="View Reply">
															<a href="<?php echo base_url($module.'/admin/lead_reply/'.$result['id']); ?>" ><i class="zmdi zmdi-eye"></i></a>
														</button>
														<!--
														<button class="item delete_category" data-toggle="tooltip" pid="<?php echo $result['id'] ?>" data-placement="top" title="" data-original-title="Delete">
															<i class="zmdi zmdi-delete"></i>
														</button>
														-->
													</div>
												</td>
											
										</tr>
									<?php endforeach; ?>
									<?php else:?>
											<tr>
												<td style="text-align: center;" colspan="15">Data not found.</td>
											</tr>
								<?php endif; ?>
							</tbody>
						</table>
						<div class = "pagination green">
							<?php echo $pagination; ?>
						</div>
					</div>
					<!-- END DATA TABLE-->
				</div>
			</div>
		</div>
	</div>
</div>
	<!-- modal medium -->
	<div class="modal fade" id="change_status_modal" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-md" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="mediumModalLabel">Change lead status</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<div class="col-sm-10 ml-auto">
						<div class="form-group">
							<label for="price" class=" form-control-label">Date</label>
							<div class="date"></div>
							<input type="hidden" name="hold_date" value="">
							<input type="hidden" name="hold_lead_id" value="">
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
					<button type="button" class="btn btn-primary put_on_hold">Confirm</button>
				</div>
			</div>
		</div>
	</div>
	<!-- end modal medium -->
<style>
.rs-select2--sm {
    width: 114px;
}
.select2-container {
    display: block !important;
}
</style>
<link href="https://cdnjs.cloudflare.com/ajax/libs/air-datepicker/2.2.3/css/datepicker.css" rel="stylesheet" media="all">
<script src="https://cdnjs.cloudflare.com/ajax/libs/air-datepicker/2.2.3/js/datepicker.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/air-datepicker/2.2.3/js/i18n/datepicker.en.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>

<script>

/* All script of same page will go here */
$('.date').datepicker({
    language: 'en',
	inline: true,
	dateFormat: "dd-mm-yyyy",
    minDate: new Date(), // Now can select only dates, which goes after today
	onSelect: function(formattedDate, date, inst)
	{
		$(document).find('input[name="hold_date"]').val(formattedDate);
	}
})

$(document).on('click','.put_on_hold',function(e) // Put date on hold
	{
		var value = 2;
		var type = 'status';
		var url = "<?php echo $module ?>/admin?status=2";
		var base_url = $('#base_url').val();
		var redirect_url = base_url+url;
		var pid = $(document).find('input[name="hold_lead_id"]').val();
		var hold_date = $(document).find('input[name="hold_date"]').val();
		
		var data = "value="+value+"&type="+type+"&pid="+pid+"&hold_date="+hold_date;
		var path = "<?php echo $module ?>/admin/change_status"
		var result = CallAjax(path,data);
		if(result.status)
		{
			location.href = redirect_url;
		}
	});
	
$(document).on('click','.delete',function(e) // Delete category
	{
		e.preventDefault();
		var id = $(this).attr('pid');
		$.confirm({
			title: 'Confirm!',
			content: 'Are you sure to delete?',
			buttons: {
				confirm: function () 
				{
					var data = "type=delete&id="+id;
					var path = "<?php echo $module ?>/admin/delete"
					var result = CallAjax(path,data);
					modalbox(result);
				},
				cancel: function () {
					
				},
			}
		});
	});	

$(document).on('change','select[name="status"]',function()
	{
		var value = $(this).val();
		var type = 'status';
		var pid = $(this).attr('lead_id');
		if(value =="2" )
		{
			$('input[name="hold_lead_id"]').val(pid);
			$('#change_status_modal').modal();
			return false;
		}
		if(value =="1")
		{
			$.confirm({
				title: 'Confirm!',
				content: 'Are you sure to close this lead?',
				buttons: {
					confirm: function () 
					{
						var data = "value="+value+"&type="+type+"&pid="+pid;
						var path = "<?php echo $module ?>/admin/change_status"
						var result = CallAjax(path,data);
						if(result.refresh)
						{
							window.location.reload();
						}
					},
					cancel: function () {
						
					},
				}
			});
			return false;
		}
		var data = "value="+value+"&type="+type+"&pid="+pid;
		var path = "<?php echo $module ?>/admin/change_status"
		var result = CallAjax(path,data);
		if(result.refresh)
		{
			window.location.reload();
		}
	});

</script>
<!-- END MAIN CONTENT-->