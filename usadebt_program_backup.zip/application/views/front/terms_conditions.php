<style>	
#main {    padding-top: 0px;    padding-bottom: 0px;	padding-left: 30px;    padding-right: 30px;}#main .fusion-row, {    max-width: 1170px;}.fusion-row {    margin: 0 auto;    zoom: 1;}#content {    float: left;    min-height: 1px;}article, aside, details, figcaption, figure, footer, header, hgroup, main, menu, nav, section {    display: block;}* {    box-sizing: border-box;}#main .fullwidth-box .fusion-row {    padding-left: 0;    padding-right: 0;}#main .fusion-row{    max-width: 1170px;}.fusion-fullwidth .fusion-row {    position: relative;    z-index: 10;}.fusion-builder-row {    width: 100%;    margin: 0 auto;}.fusion-row {    margin: 0 auto;    zoom: 1;}.fusion-layout-column.fusion-column-last {    margin-left: 0;    margin-right: 0;}.fusion-layout-column.fusion-one-full {    float: none;    clear: both;}.fusion-layout-column {    position: relative;    float: left;    margin-bottom: 20px;}.fusion-layout-column .fusion-column-wrapper {    min-height: 1px;}.fusion-text h1 {    font-size: 90px;}.post-content h1 {    color: #092933;	margin-bottom: 30px;	font-family: 'Teko', sans-serif;    font-weight: 300;    line-height: 1.1;    letter-spacing: 0px;    font-style: normal;}.fusion-modal h1 {    font-family: 'Teko';    font-weight: 300;    line-height: 1.1;    letter-spacing: 0px;    font-style: normal;}.post-content p {    margin-top: 0;    margin-bottom: 20px;}.post-content p {    margin: 0 0 20px;}.fusion-clearfix {    zoom: 1;    clear: both;}strong {    font-weight: 700;}.post-content p {    margin-top: 0;    margin-bottom: 20px;	color: #768894;	font-size: 16px;	line-height: 30px;	font-family: 'Roboto';    font-weight: 400;    letter-spacing: 0px;    font-style: normal;}</style>
<main id="main" role="main" class="clearfix " style="">
   <div class="fusion-row" style="">
      <section id="content" style="width: 100%;">
         <div id="post-1176" class="post-1176 page type-page status-publish hentry">
            <div class="post-content">
               <div class="fusion-fullwidth fullwidth-box nonhundred-percent-fullwidth non-hundred-percent-height-scrolling" style="background-color: rgba(255,255,255,0);background-position: center center;background-repeat: no-repeat;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;margin-top: 50px;">
                  <div class="fusion-builder-row fusion-row ">
                     <h1 data-fontsize="90" data-lineheight="99"><?=$title?></h1>
                     <?php
                        $pattern = "/<p[^>]*><\\/p[^>]*>/"; 
                        //$pattern = "/<[^\/>]*>([\s]?)*<\/[^>]*>/";  use this pattern to remove any empty tag
                        echo preg_replace($pattern, '', $description); 
                        ?>					
                  </div>
               </div>
            </div>
         </div>
      </section>
   </div>
</main>
<link href="https://fonts.googleapis.com/css?family=Teko:300,400,500,600,700" rel="stylesheet">
