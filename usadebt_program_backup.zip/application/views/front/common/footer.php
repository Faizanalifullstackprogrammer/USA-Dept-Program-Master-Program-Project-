<footer class="footer">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="footer_text">
					<?php 
						$phone = $this->common_model->GetSingleValue(SETTINGS_TABLE,'value',array('type' => 'phone'));
					
					?>
					<h6>Talk with a real person <a href="tel:<?php echo $phone; ?>"><?php  echo $phone; ?></a></h6>
					<h6><a href="<?php echo base_url('front/privacy_policy');?>">Privacy Policy</a> • <a href="<?php echo base_url('front/terms_conditions');?>">Terms</a></h6>
					<?php echo $this->common_model->GetSingleValue(SETTINGS_TABLE,'value',array('type' => 'footer_text'));?>
				</div>
				<div align="center">
					Website by <a href="https://www.nexustechies.com/" target="_blank">Nexus Techies</a>
				</div>
			</div>
		</div>
	</div>
</footer>



<script type="text/javascript" src="<?php echo base_url()?>/assets/front/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>/assets/front/js/font-awesome.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>/assets/front/js/slick.min.js"></script>
<script src="<?php echo base_url()?>/assets/front/js/wNumb.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>/assets/front/js/nouislider.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>/assets/front/js/custom.js"></script>


<script type="text/javascript">
$('.single-item').slick({
  infinite: false,
  dots: true,
});
</script>

<script type="text/javascript">
$("#example-embed").steps({
    headerTag: "h3",
    bodyTag: "section",
    transitionEffect: "fade"
});
</script>


</body>
</html>