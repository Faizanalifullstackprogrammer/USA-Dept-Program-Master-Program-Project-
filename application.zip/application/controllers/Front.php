<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Front extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
	}
	public function index()
	{
		$page_data['reviews'] = $this->common_model->GetTableRows(REVIEW_TABLE);
		$page_data['settlements'] = $this->common_model->GetTableRows(SETTLEMENT_TABLE,'',array('id','desc'));
		$page_data['faqs'] = $this->common_model->GetTableRows(FAQ_TABLE,'',array('orders','asc'));
		
		
			
		$this->load->view('front/common/header', $page_data);
		$this->load->view('front/home', $page_data);
		$this->load->view('front/common/footer', $page_data);
	}
	public function add_lead()
	{
		$state = strip_tags($this->input->post('state'));
		$first_name = strip_tags($this->input->post('first_name'));
		$last_name = strip_tags($this->input->post('last_name'));
		$email = $this->input->post('email');
		$phone = strip_tags($this->input->post('phone'));
		$debt_amount = strip_tags($this->input->post('debt_amount'));
		
		$ip_address = $this->input->ip_address();
	
		if(empty($state) || empty($first_name) || empty($last_name) || empty($email) || empty($phone) )
		{
				$result['status'] ="error";
				$result['html'] = "Fill All Fields.";
				$result['type'] = "alert";
		}
			
		
		$data = array
			(
				'state' => $state,
				'first_name' => $first_name,
				'last_name' => $last_name,
				'email' => $email,
				'phone' => $phone,
				'debt_amount' => $debt_amount,
				'ip_address' => $ip_address,
				'timestamp' => time(),
			);
			
			
		$insert_data = $this->common_model->InsertTableData(LEADS_TABLE,$data);
		if($insert_data)
		{
			$result['status'] = "success";
			$result['lead_id'] = $insert_data;
			$result['html'] = "Successfully Added.";
			$result['type'] = "alert";
		}
		else
		{
			$result['status'] = "error";
			$result['html'] = "Something went wrong please try again.";
			$result['type'] = "alert";
		}	
		
		echo json_encode($result);
		die();
	}
	
	public function success()
	{
		$lead_id = $this->input->get('lead_id');
		$data = $this->common_model->GetTableRows(LEADS_TABLE,array('id' => $lead_id));
		if(!count($data))
		{
			redirect(base_url());
			die();
		}
		
		
		$this->load->view('front/common/header');
		$this->load->view('front/thank_you', []);
		$this->load->view('front/common/footer');
	}
	public function privacy_policy()
	{
		$page_data = $this->common_model->GetSingleRow(PAGES_TABLE, array('slug' => 'Privacy-Policy'));
		
		$this->load->view('front/common/header');
		$this->load->view('front/privacy_policy', $page_data);
		$this->load->view('front/common/footer');
	}
	public function terms_conditions()
	{
		$page_data = $this->common_model->GetSingleRow(PAGES_TABLE, array('slug' => 'Terms-Conditions'));
		
		$this->load->view('front/common/header');
		$this->load->view('front/terms_conditions', $page_data);
		$this->load->view('front/common/footer');
	}
}

