<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {
	
	function __construct()
    {
        parent::__construct();
	} 
	
	public function change_hold_to_active_leads()
	{
		if (!$this->input->is_ajax_request()) {
		   exit('No direct script access allowed');
		}
		$condition = array('status' =>2,'hold_on <= ' => strtotime(date('d-m-Y')) );
		$this->db->set('status',0, FALSE);
		$this->db->where($condition);

		if($this->db->update(LEADS_TABLE))
		{
			if($this->db->affected_rows())
			{
				echo "sucess";
			}
			else
			{
				echo "Not found";
			}
		}
	}
	
	public function count_days_of_open_leads()
	{
		$active_leads = $this->common_model->GetTableRows(LEADS_TABLE,array('activated_for >' => 1,'generate_leads_for > ' => 1, 'assigned_on <' => time()));
		$last_lead_generated_on = $this->common_model->GetSingleValue(SETTINGS_TABLE,'value',array('type' => 'last_lead_generated_on'));
		$currtent_date = strtotime(date('d-m-Y'));
		if($last_lead_generated_on < $currtent_date)
		{
			// if leads exist to generate new lead;
			if($active_leads)
			{
				foreach($active_leads as $lead_data)
				{
					
					$generate_leads_for = $lead_data['generate_leads_for'];
					
					// generate new data;
					$new_lead_data['user_id'] = $lead_data['user_id'];
					$new_lead_data['product_name'] = $lead_data['product_name'];
					$new_lead_data['phone'] = $lead_data['phone'];
					$new_lead_data['purpose'] = $lead_data['purpose'];
					$new_lead_data['price'] = $lead_data['price'];
					$new_lead_data['remark'] = $lead_data['remark'];
					$new_lead_data['images'] = $lead_data['images'];
					$new_lead_data['activated_for'] = $lead_data['generate_leads_for']-1;
					$new_lead_data['assigned_on'] = $currtent_date;
					$new_lead_data['appear_on'] = $currtent_date;
					$insert_id = $this->common_model->InsertTableData(LEADS_TABLE,$new_lead_data);
					if($insert_id)
					{
						$this->common_model->UpdateTableData(LEADS_TABLE,array('generate_leads_for' => $generate_leads_for-1),array('id' => $lead_data['id']));
						$url = base_url('leads/admin?id='.$insert_id);
						$email = $this->common_model->GetSingleValue(USERS_TABLE,'email',array('id' => $lead_data['user_id']));
						$name = $this->common_model->GetSingleValue(USERS_TABLE,'name',array('id' => $lead_data['user_id']));
						
						$template = $this->load->view('email_templates/lead_added','',true);
						$replace_from = array('{{email}}','{{name}}','{{url}}');
						$replace_to = array($email,$name,$url);
						$template = str_replace($replace_from,$replace_to,$template);

						$this->common_model->SendEmail($email,EMAIL_SENDER,'New Lead Assigned',$template);
					}
					
					
					/* $from = date('d-m-Y',$lead['assigned_on']);
					$to = date('d-m-Y');

					$diff = abs(strtotime($to) - strtotime($from));

					$years = floor($diff / (365*60*60*24));
					$months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
					$days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
					
					if(strtotime($from) <> strtotime($to))
					{
						$update_data['assigned_on'] = strtotime($to);
						$update_data['activated_for'] =  $lead['activated_for']-$days;
						$this->common_model->UpdateTableData(LEADS_TABLE,$update_data,array('id' => $lead['id']));
					} */
					
				}
			}
			// Update last lead generation date
			$this->common_model->UpdateTableData(SETTINGS_TABLE,array('value' => $currtent_date),array('type' => 'last_lead_generated_on'));
					
		}
	}
	
}
