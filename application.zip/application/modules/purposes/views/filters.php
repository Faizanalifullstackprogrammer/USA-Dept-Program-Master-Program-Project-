 <div class="filters m-b-45">
	<div class="rs-select2--dark rs-select2--md m-r-10 rs-select2--border">
		<select class="js-select2" name="property">
			<option selected="selected">All Properties</option>
			<option value="">Products</option>
			<option value="">Services</option>
		</select>
		<div class="dropDownSelect2"></div>
	</div>
	<div class="rs-select2--dark rs-select2--sm rs-select2--border">
		<select class="js-select2 au-select-dark" name="time">
			<option selected="selected">All Time</option>
			<option value="">By Month</option>
			<option value="">By Day</option>
		</select>
		<div class="dropDownSelect2"></div>
	</div>
</div>