<?php
class Teachers_model extends CI_Model
{
	
	
}
?>
