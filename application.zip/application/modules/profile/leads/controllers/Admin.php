<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Admin extends CI_Controller
{
	private $controller_name;
	
	function __construct()
	{
		parent::__construct();
		$this->common_model->CheckUserSession(); /// secure login 
		$this->controller_name = $this->router->fetch_class();
		$this->method_name = $this->router->fetch_method();
		$this->_module = $this->router->fetch_module();
		$this->path =$this->_module.'/'.$this->controller_name;
		$this->user_id = $this->session->userdata('user_id');
	}
	
	public function index()
	{
		$user_id = $this->user_id;
		$where = [];
		if(!$this->common_model->is_admin())
		{
			$where[]= "user_id = '$user_id' ";
		}
		$where[] = " status = '0' ";
		
		$current_time = time();
		$where[] = " (appear_on ='' ||  appear_on< '$current_time') "; // show only old leads;
		
		
		$where = self::filter_query($where);
		$where = implode(' AND ', $where);
		$config["base_url"] = base_url().$this->path."/".$this->method_name;
		$config["total_rows"] = $this->common_model->GetTotalCount(LEADS_TABLE, $where);
		$result_per_page = $this->common_model->GetSingleValue(SETTINGS_TABLE,'value',array('type' => 'result_per_page'));
		$config["per_page"] = $result_per_page;
		$config['uri_segment'] = 4;
		$limit = $config['per_page'];
		$config['reuse_query_string'] = true;
		$this->pagination->initialize($config);
		$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		$page_data["results"] = $this->common_model->GetTableRows(LEADS_TABLE,$where,array('id','desc'),$limit,$page);
		$page_data['all_users'] = $this->common_model->SelectDropdown(USERS_TABLE,'name','id',array($this->input->post('user_id')), array('active' => 1,'admin <> ' => 1));
		$page_data["pagination"] = $this->pagination->create_links();
		$controllerName =  $this->_module.'/admin';
		$module = $this->_module;
		$page_data['module_title'] = ucfirst($module);
		
		
		$page_data['module'] = $module;
		$this->load->view('common/header');
		$this->load->view($module.'/detail',$page_data);
		$this->load->view('common/footer');
	}
	
	public function hold_leads()
	{
		$user_id = $this->user_id;
		$where = [];
		if(!$this->common_model->is_admin())
		{
			$where[]= "user_id = '$user_id' ";
		}
		$where[] = " status = '2' ";
		
		$current_time = time();
		$where[] = " (appear_on ='' ||  appear_on< '$current_time') "; // show only old leads;
		
		
		$where = self::filter_query($where);
		$where = implode(' AND ', $where);
		$config["base_url"] = base_url().$this->path."/".$this->method_name;
		$config["total_rows"] = $this->common_model->GetTotalCount(LEADS_TABLE, $where);
		$result_per_page = $this->common_model->GetSingleValue(SETTINGS_TABLE,'value',array('type' => 'result_per_page'));
		$config["per_page"] = $result_per_page;
		$config['uri_segment'] = 4;
		$limit = $config['per_page'];
		$config['reuse_query_string'] = true;
		$this->pagination->initialize($config);
		$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		$page_data["results"] = $this->common_model->GetTableRows(LEADS_TABLE,$where,array('id','desc'),$limit,$page);
		$page_data['all_users'] = $this->common_model->SelectDropdown(USERS_TABLE,'name','id',array($this->input->post('user_id')), array('active' => 1,'admin <> ' => 1));
		$page_data["pagination"] = $this->pagination->create_links();
		$controllerName =  $this->_module.'/admin';
		$module = $this->_module;
		$page_data['module_title'] = "Hold Leads";
		
		
		$page_data['module'] = $module;
		$this->load->view('common/header');
		$this->load->view($module.'/detail',$page_data);
		$this->load->view('common/footer');
	}
	public function close_leads()
	{
		$user_id = $this->user_id;
		$where = [];
		if(!$this->common_model->is_admin())
		{
			$where[]= "user_id = '$user_id' ";
		}
		$where[] = " status = '1' ";
		
		$current_time = time();
		$where[] = " (appear_on ='' ||  appear_on< '$current_time') "; // show only old leads;
		
		
		$where = self::filter_query($where);
		$where = implode(' AND ', $where);
		$config["base_url"] = base_url().$this->path."/".$this->method_name;
		$config["total_rows"] = $this->common_model->GetTotalCount(LEADS_TABLE, $where);
		$result_per_page = $this->common_model->GetSingleValue(SETTINGS_TABLE,'value',array('type' => 'result_per_page'));
		$config["per_page"] = $result_per_page;
		$config['uri_segment'] = 4;
		$limit = $config['per_page'];
		$config['reuse_query_string'] = true;
		$this->pagination->initialize($config);
		$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		$page_data["results"] = $this->common_model->GetTableRows(LEADS_TABLE,$where,array('id','desc'),$limit,$page);
		$page_data['all_users'] = $this->common_model->SelectDropdown(USERS_TABLE,'name','id',array($this->input->post('user_id')), array('active' => 1,'admin <> ' => 1));
		$page_data["pagination"] = $this->pagination->create_links();
		$controllerName =  $this->_module.'/admin';
		$module = $this->_module;
		$page_data['module_title'] = "Close Leads";
		
		
		$page_data['module'] = $module;
		$this->load->view('common/header');
		$this->load->view($module.'/detail',$page_data);
		$this->load->view('common/footer');
	}
	public function filter_query($where = [])
	{
		foreach($_GET as $key => $value)
		{
			$value = strip_tags($value);
			if($key <> "from" && $key <> "to")
			{
				if($key == "type")
				{
					if($value <> "")
					{
						$where[] = "  $key LIKE '%$value%'   ";
					}
				}
				else
				{
					if($value <> "")
					{
						$where[] = "  $key = '$value'   ";
					}
				}
			}
		}
		return $where; 
	}
	
	public function add()
	{
		if(!$this->common_model->is_admin())
		{
			redirect('dashboard/admin');
		}
		
		if($this->input->post('s')) // if form submitted
		{
			$product_name = strip_tags($this->input->post('product_name'));
			$phone = strip_tags($this->input->post('phone'));
			$purpose = strip_tags($this->input->post('purpose'));
			$price = strip_tags($this->input->post('price'));
			$remark = strip_tags($this->input->post('remark'));
			$user_id = strip_tags($this->input->post('user_id'));
			$activated_for = strip_tags($this->input->post('activated_for'));
			
			$found = 0;
			foreach($_POST as $key => $val)
			{
				if($key <> "s" && $key <> "user_id")
				{
					if(!empty(trim($val)))
					{
						$found++;
					}
				}
			}
			if($found < 1) // at least one fild should be filled.
			{
				$this->session->set_flashdata('flash_message','Please fill at least one field.');
				$this->session->set_flashdata('class','danger');
				redirect(base_url($this->path.'/add'));
			}
			
			$this->form_validation->set_rules('user_id', 'Assigned user', 'trim|required|xss_clean');
			
			if ($this->form_validation->run() == true)
			{
				$images = self::upload_documents();
				$data = array
					(
						'user_id' => $user_id,
						'product_name' => $product_name,
						'phone' =>  $phone,
						'purpose' =>  $purpose,
						'price' =>  $price,
						'remark' =>  $remark,
						'activated_for' =>  empty($activated_for) ? 1 : $activated_for,
						'images' =>  $images,
						'assigned_on' =>  time(),
						'generate_leads_for' =>  empty($activated_for) ? 1 : $activated_for,
					);
					
				$insert_id = $this->common_model->InsertTableData(LEADS_TABLE,$data);
				if($insert_id)
				{
					/* $activated_for = intval($activated_for);
					if(!empty($activated_for))
					{
						$total_days_left = $activated_for-1; // first lead aleardy inserted;
						// Now add ( for loop  )
						
						$today_timestamp = strtotime(date('d-m-Y'));
						$child_data = array();
						$parent_lead_id = 1;
						for($i=$total_days_left;$i >= 1;$i--)
						{
							$today_timestamp = $today_timestamp+86400;
							$child_data[] = array
											(
												'user_id' => $user_id,
												'product_name' => $product_name,
												'phone' =>  $phone,
												'purpose' =>  $purpose,
												'price' =>  $price,
												'remark' =>  $remark,
												'activated_for' =>  $i,
												'images' =>  $images,
												'assigned_on' =>  $today_timestamp,
												'appear_on' =>  $today_timestamp,
												'parent_lead_id' =>  $insert_id,
											);
							
						}
						$this->common_model->InsertMultipleData(LEADS_TABLE,$child_data);
					}
					 */
					$this->session->set_flashdata('flash_message','Lead successfully assigned.');
					$this->session->set_flashdata('class','success');
					redirect(base_url($this->path."?status=0"));
					die();
				}
				else
				{
					$this->session->set_flashdata('flash_message','Something went wrong please try again.');
					$this->session->set_flashdata('class','danger');
					redirect(base_url($this->path));
					die();
				}	
			}
		}
		
		$page_data['module_path'] = $this->path;
		$module = $this->_module;
		$controllerName =  $this->_module.'/admin';
		$page_data['module_title'] = $module." : Add ";
		$page_data['module'] = $module;
		$page_data['users'] = $this->common_model->SelectDropdown(USERS_TABLE,'name','id',array($this->input->post('user_id')), array('active' => 1,'admin <> ' => 1));
		$page_data['purposes'] = $this->common_model->SelectDropdown(PURPOSES_TABLE,'title','id',array($this->input->post('purpose')));
		$this->load->view('common/header');
		$this->load->view($module.'/forms/add',$page_data);
		$this->load->view('common/footer');
	}
	
	
	public function upload_documents()
	{
		$total_documents = count($_FILES['images']['name']);
		$files = $_FILES;
		$document_array = [];
		$this->load->helper('inflector');
		if(!empty($_FILES['images']['name'][0]))
		{
			for($i=0; $i<$total_documents; $i++)
			{      
				$_FILES['file']['name']= $files['images']['name'][$i];
				$_FILES['file']['type']= $files['images']['type'][$i];
				$_FILES['file']['tmp_name']= $files['images']['tmp_name'][$i];
				$_FILES['file']['error']= $files['images']['error'][$i];
				$_FILES['file']['size']= $files['images']['size'][$i];

				$name = $files['images']['name'][$i];
				$upload_dir = dirname(APPPATH)."/uploads";
				$t = explode(".", $name);
				$ext = end($t);

				$file_info = pathinfo($name);
				$file_name = $file_info['filename'];
				$replaced_name = preg_replace("/[^a-zA-Z]+/", "", $file_name);
				$name = $replaced_name.'.'.$file_info['extension'];

				$config['upload_path'] = dirname(APPPATH)."/uploads";
				$config['allowed_types'] = 'jpg|jpeg|png';
				$config['max_size'] = "10048";
				
				
				$file_name = $name;
				$config['file_name'] = time().'_'.$file_name;
				
				$this->load->library("upload", $config);
				$this->upload->initialize($config);

				if($this->upload->do_upload('file'))
				{
					$document_array[] = $config['file_name'];
				}
			}
		}
		$serialize = serialize($document_array);
		return $serialize;
	}
	
	
	public function edit($id) // Update function
	{
		if(!$this->common_model->is_admin())
		{
			redirect('dashboard/admin');
		}
		
		$page_data = (array)$this->common_model->GetSingleRow(LEADS_TABLE,array('id' => $id)); // get data
		if(!count($page_data)) { redirect(base_url($this->_module.'/admin')); }
		
		if($this->input->post('s')) // if form submitted
		{
			$product_name = strip_tags($this->input->post('product_name'));
			$phone = strip_tags($this->input->post('phone'));
			$purpose = strip_tags($this->input->post('purpose'));
			$price = strip_tags($this->input->post('price'));
			$remark = strip_tags($this->input->post('remark'));
			$user_id = strip_tags($this->input->post('user_id'));
			$activated_for = strip_tags($this->input->post('activated_for'));
			
			$found = 0;
			foreach($_POST as $key => $val)
			{
				if($key <> "s" && $key <> "user_id")
				{
					if(!empty(trim($val)))
					{
						$found++;
					}
				}
			}
			if($found < 1) // at least one fild should be filled.
			{
				$this->session->set_flashdata('flash_message','Please fill at least one field.');
				$this->session->set_flashdata('class','danger');
				redirect(base_url($this->path.'/edit/'.$id));
			}

			$this->form_validation->set_rules('user_id', 'Assigned user', 'trim|required|xss_clean');
			
			if ($this->form_validation->run() == true)
			{
				$images = self::upload_documents();
				if($this->input->post('uploaded_images[]'))
				{
					$unserialize = unserialize($images);
					$new_documents_array = array_diff($unserialize,$_POST['uploaded_images']);
					$new_array = array_merge($_POST['uploaded_images'],$new_documents_array);
					$delete_array = array_diff($_POST['uploaded_images'],$new_array);
					foreach($delete_array as $file)
					{
						@unlink(FCPATH.'uploads/'.$file); // delete old file;
					}
					$images = serialize($new_array);
				}
				
				$data = array
					(
						'user_id' => $user_id,
						'product_name' => $product_name,
						'phone' =>  $phone,
						'purpose' =>  $purpose,
						'price' =>  $price,
						'remark' =>  $remark,
						'activated_for' =>  $activated_for,
						'images' =>  $images,
						'assigned_on' =>  time(),
					);
					
				$update_data = $this->common_model->UpdateTableData(LEADS_TABLE,$data,array('id' => $id));
				if($update_data)
				{
					$this->session->set_flashdata('flash_message','Lead successfully updated.');
					$this->session->set_flashdata('class','success');
					redirect(base_url($this->path."?status=0"));
					die();
				}
				else
				{
					$this->session->set_flashdata('flash_message','Something went wrong please try again.');
					$this->session->set_flashdata('class','danger');
					redirect(base_url($this->path));
					die();
				}	
			}
		}
		
		$page_data['module_path'] = $this->path;
		$module = $this->_module;
		$controllerName =  $this->_module.'/admin';
		$page_data['module_title'] = $module." : Edit ";
		$page_data['module'] = $module;
		$page_data['users'] = $this->common_model->SelectDropdown(USERS_TABLE,'name','id',array($page_data['user_id']), array('active' => 1,'admin <> ' => 1));
		$page_data['purposes'] = $this->common_model->SelectDropdown(PURPOSES_TABLE,'title','id',array($page_data['purpose']));
		
		$this->load->view('common/header');
		$this->load->view($module.'/forms/edit',$page_data);
		$this->load->view('common/footer');
		
	}
	
	/* Delete function */
	
	public function delete()
	{
		if(!$this->common_model->is_admin())
		{
			redirect('dashboard/admin');
		}
		
		$id = $this->input->post('id');
		$update_data = $this->common_model->DeleteTableData(LEADS_TABLE,array('id' => $id));
		if($update_data)
		{
			$result['status'] = "success";
			$result['html'] = "Lead Successfully Deleted.";
			$result['type'] = "alert";
		}
		else
		{
			$result['status'] = "error";
			$result['html'] = "Something went wrong please try again.";
			$result['type'] = "alert";
		}
		echo json_encode($result);
	}
	
	public function change_status()
	{
		$type = $this->input->post('type');
		$value = $this->input->post('value');
		$pid = $this->input->post('pid');
		$this->db->set($type,$value, FALSE);
		if($value == "2")
		{
			$hold_date = $this->input->post('hold_date');
			if(empty($hold_date))
			{
				$hold_date = date('d-m-Y');
			}
			$hold_date = strtotime($hold_date);
			$this->db->set('hold_on',$hold_date, FALSE);
		}
		if($value == "1")
		{
			$this->db->set('closed_on',time(), FALSE);
		}
		
		$this->db->where('id',$pid);
		$this->db->update(LEADS_TABLE);
		if($this->db->affected_rows())
		{
			if($value == "1")
			{
				/* $lead_data = $this->common_model->GetSingleRow(LEADS_TABLE,array('id' => $pid));
				$activated_for = $lead_data->activated_for;
				if($activated_for > 0)
				{
					// create new lead for next day;
					$previous_assigned_on_timestamp = $lead_data->assigned_on;
					$assigned_date = strtotime(date('d-m-Y',$previous_assigned_on_timestamp));
					$nextday = $assigned_date + 86400 - ($assigned_date % 86400);
					
					$new_lead_data['user_id'] = $lead_data->user_id;
					$new_lead_data['product_name'] = $lead_data->product_name;
					$new_lead_data['phone'] = $lead_data->phone;
					$new_lead_data['purpose'] = $lead_data->purpose;
					$new_lead_data['price'] = $lead_data->price;
					$new_lead_data['remark'] = $lead_data->remark;
					$new_lead_data['images'] = $lead_data->images;
					$new_lead_data['activated_for'] = $lead_data->activated_for-1;
					$new_lead_data['assigned_on'] = $nextday;
					$new_lead_data['appear_on'] = $nextday;
					$insert_id = $this->common_model->InsertTableData(LEADS_TABLE,$new_lead_data);
				} */
			}
			
			$result['status'] = "success";
			$result['html'] = "Data successfully updated";
			$result['type'] = "alert";
			if($value == "1")
			{
				$result['refresh'] = "ok";
			}
		}
		else
		{
			$result['status'] = "error";
			$result['html'] = "Something went wrong please try again.";
			$result['type'] = "alert";
		}
		echo json_encode($result);
	}
	
	// get lead replies
	public function lead_reply($id)
	{
		$user_id = $this->user_id;
		$page_data = (array)$this->common_model->GetSingleRow(LEADS_TABLE,array('id' => $id)); // get data
		if(!count($page_data)) { redirect(base_url($this->_module.'/admin')); }
		
		if(!$this->common_model->is_admin())
		{
			if($user_id <> $page_data['user_id']) // if not same user
			{
				$this->session->set_flashdata('flash_message','Not a valid lead you are trying to access.');
				$this->session->set_flashdata('class','danger');
				redirect(base_url($this->path));
				die();
			}
		}
		$page_data['lead_replys'] = $this->common_model->GetTableRows(LEADS_REPLY_TABLE,array('lead_id' =>$id ),array('id','asc'));
		
		$page_data['module_path'] = $this->path;
		$module = $this->_module;
		$controllerName =  $this->_module.'/admin';
		$page_data['module_title'] = $module." : Reply ";
		$page_data['module'] = $module;
		$this->load->view('common/header');
		$this->load->view($module.'/reply',$page_data);
		$this->load->view('common/footer');
	}
	
	
	public function add_reply()
	{
		if (!$this->input->is_ajax_request()) {
		   exit('No direct script access allowed');
		}
		
		$from_id = $this->session->userdata('user_id');
		$lead_id = $this->input->post('lead_id');
		$message =  strip_tags($this->input->post('message'));
		// update last seen 
		$this->common_model->UpdateTableData(LEADS_REPLY_TABLE,array('seen' => 1),array('lead_id' =>$lead_id,'receiver_id' =>$from_id,'seen' =>0  ));
		
		
		
		$assigned_user_id = $this->common_model->GetSingleValue(LEADS_TABLE,'user_id',array('id' => $lead_id));
		
		if($assigned_user_id == $from_id)
		{
			$to_id = $this->common_model->GetSingleValue(USERS_TABLE,'id',array('admin' => 1)); // admin is receiver
		}
		else
		{
			$to_id = $assigned_user_id;
		}
		
		$data  = array
				(
					'lead_id' => $lead_id,
					'sender_id' => $from_id,
					'receiver_id' => $to_id,
					'message' => $message,
					'timestamp' => time(),
				);

		$insert_id = $this->common_model->InsertTableData(LEADS_REPLY_TABLE,$data);
		if($insert_id)
		{
			$name = $this->common_model->GetSingleValue(USERS_TABLE,'name',array('id' => $from_id));
			
			$time_ago = $this->common_model->Timeago($data['timestamp']);
			$html = '<div class="user_chat">
						<span>'.$message.'<i>'.$time_ago.'</i></span>
					</div>';
			$json_data['status'] = "success";
			$json_data['html'] = $html;
		}
		else
		{
			$json_data['status'] = "error";
		}

		echo json_encode($json_data);
	}
}
?>
