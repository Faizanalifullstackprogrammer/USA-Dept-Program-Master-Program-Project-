<style>
#main {
    padding-top: 0 !important;
    padding-bottom: 0px;
	padding-left: 30px;
	padding-right: 30px;
}
#main body, html {
    background-color: #ffffff;
}
#main .fusion-row
{
	max-width: 1170px;
}
.fusion-row {
    margin: 0 auto;
    zoom: 1;
}
#content {
    width: 71.1702128%;
    float: left;
    min-height: 1px;
}
.post-content h1 {    font-family: 'Teko', sans-serif;    font-weight: 300;    line-height: 1.1;    letter-spacing: 0px;    font-style: normal;    font-size: 90px;	color: #092933;}

.post-content p {
    margin-top: 0;
    margin-bottom: 20px;
	color: #768894;
	font-size: 16px;
	line-height: 30px;
	font-family: 'Roboto', sans-serif;
    font-weight: 400;
    letter-spacing: 0px;
    font-style: normal;
}
ol{
	color: #768894;
	font-size: 16px;
	font-family: 'Roboto', sans-serif;
    font-weight: 400;
    letter-spacing: 0px;
    font-style: normal;
}
ul{
	color: #768894;
	font-size: 16px;
	font-family: 'Roboto', sans-serif;
    font-weight: 400;
    letter-spacing: 0px;
    font-style: normal;
}
.post-content h2 {
    font-family: 'Teko';
    font-weight: 400;
    line-height: 1.0;
    letter-spacing: 0px;
    font-style: normal;
	color: #092933;
    font-size: 65px;
}

* {
    box-sizing: border-box;
}
</style>
<main id="main" role="main" class="clearfix " style="">
	<div class="fusion-row" style="">
		<section id="content" style="width: 100%;">
			<div id="post-1176" class="post-1176 page type-page status-publish hentry">
				<div class="post-content">
					<div class="fusion-fullwidth fullwidth-box nonhundred-percent-fullwidth non-hundred-percent-height-scrolling" style="background-color: rgba(255,255,255,0);background-position: center center;background-repeat: no-repeat;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;margin-top: 50px;">
						<div class="fusion-builder-row fusion-row ">
							<h1 data-fontsize="90" data-lineheight="99"><?=$title?></h1>	
							<?php
								$pattern = "/<p[^>]*><\\/p[^>]*>/"; 
								//$pattern = "/<[^\/>]*>([\s]?)*<\/[^>]*>/";  use this pattern to remove any empty tag
								echo preg_replace($pattern, '', $description); 
							?>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
</main>
<link href="https://fonts.googleapis.com/css?family=Teko:300,400,500,600,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
