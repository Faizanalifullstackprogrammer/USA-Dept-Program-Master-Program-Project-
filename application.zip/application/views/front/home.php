<section class="midd_content">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="step_tagline">
					<p>See If You Qualify for Debt Relief-Legally Resolve Most of the Debt You Owe.</p>
				</div>
			</div>
		</div>
		<div class="row quatation_form">
			<div class="col-md-12">
				<div class="progressLine"> <span id="pgLine"> PROGRESS <span>10</span>% </span> </div>
				<section class="quoteForm">
			      <form  method="post" id="leadForm" action="<?php echo base_url(''); ?>">
			               
			        <div id="" class="step active">
			          <div class="sliderContent">
			            <h2>How much debt do you&nbsp;have?</h2>
			            <p class="subtitle">(don't include mortgage and car loans)</p>
			            <span class="slider-val" id="slider-debt-value"></span>
			            <div class="sliderContainer">
			              <div id="slider-debt"></div>
			            </div>
			            <input type="hidden" name="debt_amount" id="debt_amount" value="" />
			            <button data-range="addValues-20%,addValues2-10%" class="continue goToRanges" id="debt_check">Get Started &raquo;</button>
			          </div>
			        </div>
			        <!--End Step-->
			        <div class="step">
			          <div class="iconContainer">
			            <h2>How far behind are you on payments?</h2>
			            <div class="item">
			              <div class="img"> <img src="<?php echo base_url()?>/assets/front/images/like.png"/> </div>
			              <h3 class="not_behind"><span>Not Behind</span></h3>
			            </div>
			            <div class="item">
			              <div class="img"> <img src="<?php echo base_url()?>/assets/front/images/flag.png"/> </div>
			              <h3 class="30_days"><span>30 Days</span></h3>
			            </div>
			            <div class="item">
			              <div class="img"> <img src="<?php echo base_url()?>/assets/front/images/piggy-bank.png"/> </div>
			              <h3 class="60_days"><span>60 Days</span></h3>
			            </div>
			            <input type="hidden" name="behind" id="behind" value="" />
			          </div>
			        </div>
			        <!--End step-->
			        <div class="step">
			          <div class="container my-0">
			            <div class="row">
			              <div class="col-md-12 text-center">
			                <h2>In what state do you&nbsp;live?</h2>
			              </div>
			            </div>
			            <div class="row">
			              <div class="col-md-6 my-4 mx-auto">
			                <div class="form-group">
			                    <select class="form-control form-control-lg" name="state" id="state" required>
			                    <option value="AL">AL (Alabama)</option><option value="AK">AK (Alaska)</option><option value="AZ">AZ (Arizona)</option><option value="AR">AR (Arkansas)</option><option value="CA">CA (California)</option><option value="CO">CO (Colorado)</option><option value="CT">CT (Connecticut)</option><option value="DE">DE (Delaware)</option><option value="DC">DC (Washington DC)</option><option value="FL">FL (Florida)</option><option value="GA">GA (Georgia)</option><option value="HI">HI (Hawaii)</option><option value="ID">ID (Idaho)</option><option value="IL">IL (Illinois)</option><option value="IN">IN (Indiana)</option><option value="IA">IA (Iowa)</option><option value="KS">KS (Kansas)</option><option value="KY">KY (Kentucky)</option><option value="LA">LA (Louisiana)</option><option value="ME">ME (Maine)</option><option value="MD">MD (Maryland)</option><option value="MA">MA (Massachusetts)</option><option value="MI">MI (Michigan)</option><option value="MN">MN (Minnesota)</option><option value="MS">MS (Mississippi)</option><option value="MO">MO (Missouri)</option><option value="MT">MT (Montana)</option><option value="NE">NE (Nebraska)</option><option value="NV">NV (Nevada)</option><option value="NH">NH (New Hampshire)</option><option value="NJ">NJ (New Jersey)</option><option value="NM">NM (New Mexico)</option><option value="NY">NY (New York)</option><option value="NC">NC (North Carolina)</option><option value="ND">ND (North Dakota)</option><option value="OH">OH (Ohio)</option><option value="OK">OK (Oklahoma)</option><option value="OR">OR (Oregon)</option><option value="PA">PA (Pennsylvania)</option><option value="RI">RI (Rhode Island)</option><option value="SC">SC (South Carolina)</option><option value="SD">SD (South Dakota)</option><option value="TN">TN (Tennessee)</option><option value="TX">TX (Texas)</option><option value="UT">UT (Utah)</option><option value="VT">VT (Vermont)</option><option value="VA">VA (Virginia)</option><option value="WA">WA (Washington)</option><option value="WV">WV (West Virginia)</option><option value="WI">WI (Wisconsin)</option><option value="WY">WY (Wyoming)</option>                  </select>
			                  <label class="form-control-placeholder" for="state">State</label>
			                </div>
			              </div>
			            </div>
			            <div class="row">
			              <div class="col-md-12 text-center">
			                <button class="continue" id="address_check">Continue &raquo; </button>
			              </div>
			            </div>
			          </div>
			        </div>
			        <!--End step-->
			        <div class="step">
			          <div class="container my-0">
			            <div class="row">
			              <div class="col-md-12 text-center">
			                <h2>What's your name?</h2>
			              </div>
			            </div>
			            <div class="row">
			              <div class="col-md-6 my-4 mx-auto">
			                <div class="form-group">
			                  <input type="text" name="first_name" id="first_name" class="form-control form-control-lg" required>
			                  <label class="form-control-placeholder" for="first_name">First Name</label>
			                  <p class="form-text text-danger" id="firstNameError"></p>
			                </div>
			                <div class="form-group">
			                  <input type="text" name="last_name" id="last_name" class="form-control form-control-lg" required required>
			                  <label class="form-control-placeholder" for="last_name">Last Name</label>
			                  <p class="form-text text-danger" id="lastNameError"></p>
			                </div>
			              </div>
			            </div>
			            <div class="row">
			              <div class="col-md-12 text-center">
			                <button class="continue " id="name_check">Continue &raquo; </button>
			              </div>
			            </div>
			          </div>
			        </div>
			        <!--End step-->
			        <div class="step">
			          <div class="container my-0">
			            <div class="row">
			              <div class="col-md-12 text-center">
			                <h2>Final step. What are your basic contact&nbsp;details?</h2>
			                <p class="subtitle">Complete to Receive the FREE eBook: "Deliverance from Debt: How Debt Settlement Helped Me Resolve My Debt in 24 Months"</p>
			              </div>
			            </div>
			            <div class="row">
			              <div class="col-md-6 my-4 mx-auto">
			                <div class="form-group">
			                  <input type="email" name="email" id="email" class="form-control form-control-lg" required>
			                  <label class="form-control-placeholder" for="email">Email</label>
			                  <p class="form-text text-danger" id="emailError"></p>
			                </div>
			                <div class="form-group">
			                  <input type="tel" name="phone" id="phone" class="form-control form-control-lg" required>
			                  <label class="form-control-placeholder" for="phone">Phone</label>
			                  <p class="form-text text-danger" id="phoneError"></p>
			                </div>
			              </div>
			            </div>
			            <div class="row">
			              <div class="col-md-12 text-center">
			                <button class="continue form_submit_data" id="contact_check">See If You Qualify &raquo; </button>
			                <article>
			                  <p id="tcpa_disclosure">
			                    <input type="hidden" id="leadid_tcpa_disclosure"/>
			                    We take your privacy seriously. By clicking the button, you agree to share your information with us and <a href='#' target='_blank'>our partners</a>, and for them to contact you (including through automated means; e.g. autodialing, text and pre-recorded messaging) via telephone, mobile device (including SMS and MMS) and/or email, even if your telephone number is currently listed on any state, federal or corporate Do Not Call list. Consent is not required as a condition to purchase a good/service.</p>
			                  <input type="hidden" name="tcpa" value="We take your privacy seriously. By clicking the button, you agree to share your information with us and <a href='/partners/' target='_blank'>our partners</a>, and for them to contact you (including through automated means; e.g. autodialing, text and pre-recorded messaging) via telephone, mobile device (including SMS and MMS) and/or email, even if your telephone number is currently listed on any state, federal or corporate Do Not Call list. Consent is not required as a condition to purchase a good/service.">
			                </article>
			              </div>
			            </div>
			          </div>
			        </div>
			        <!--End step-->
			      </form>
			    </section>
			</div> 
			<div class="col-md-12">
				<div class="subform">
					<p>100% FREE • No SSN Required • Takes Just 20 Seconds • Won't Hurt to Check</p>
					<div class="security">
						<img src="<?php echo base_url()?>/assets/front/images/bbb-icon.gif" alt="bbb-icon">
						<span>BBB Accredited Business</span><br/>
						<img src="<?php echo base_url()?>/assets/front/images/lock-icon.gif" alt="lock-icon">
						<span>Privacy Protected</span>
					</div>
					<div class="partners">
						<span>As Seen On: </span>
						<img src="<?php echo base_url()?>/assets/front/images/forbes.png" alt="forbes">
						<img src="<?php echo base_url()?>/assets/front/images/cnn.png" alt="cnn">
						<img src="<?php echo base_url()?>/assets/front/images/us-news.png" alt="us-news">
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-12">
				<div class="testimonials">
					<h2>What People Are Saying:</h2>
					<div class="single-item">
						<?php if(!empty($reviews))
						{   
							foreach($reviews as $review)
							{    ?>
								<div>
									<div class="testimonial_content">
										<p><?php echo $review['description']; ?></p>
									</div>
									<div class="review_image">
										<div class="r_image">
											<img src="<?php echo base_url('uploads/'.$review['image']);?>" alt="">
										</div>
										<div class="r_detail">
											<span class="name"><b><?php echo ucfirst($review['name']);?></b></span>
											<p class="addres"><?php echo $review['address'];?></p>
											<span class="star_ratting">
												<ul class="display">
													<?php 
														$rating_html="";
														$rating = $review['rating'];
														
														for($i=1;$i <=5;$i++)
														{
															$colored = "";
															if($i <= $rating)
															{
																$colored = "colored";
																
															} 
															
															$rating_html .= '<li title="'.$i.' Star"   class="'.$colored.'"><i class="fa fa-star"></i></li>';
														}
														echo $rating_html; 
													?>
												</ul>
											</span>
										</div>
									</div>
								</div>
								<?php 
							}
						}
						?>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="Settlements">
					<h2>Recent Settlements*</h2>
					<table class="table table-bordered table-hover table-striped">
				    <thead>
				      <tr>
				        <th>Creditor</th>
				        <th class="text-right">Debt Amount</th>
				        <th class="text-right">Settlement</th>
				        <th class="text-right">Savings</th>
				      </tr>
				    </thead>
				    <tbody>
				      <?php if($settlements): ?>
						<?php foreach($settlements as $settlement): ?>
							<tr>
								<td class="text-right"><?php echo ucfirst($settlement['creditor'])?></td>
								<td class="text-right"><?php echo '$'.$settlement['debt_amount']?></td>
								<td class="text-right"><?php echo '$'.$settlement['settlement']?></td>
								<td class="text-right"><?php echo $settlement['savings'].'%'?></td>
							</tr>
						<?php endforeach; ?>
						<?php else:?>
								<tr>
									<td style="text-align: center;" colspan="15">Data not found.</td>
								</tr>
						<?php endif; ?>
				    </tbody>
				  </table>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="accodian">
					<h2>Frequently Asked Questions</h2>
					<div class="panel-group" id="accordion">
						<?php 
							if(!empty($faqs)):

								foreach($faqs as $key => $faq): ?>
								<div class="panel panel-default">
									<div class="panel-heading">
									  <h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $key;?>">
											<?php echo $faq['question'] ?></a>
									  </h4>
									</div>
									<div id="collapse<?php echo $key;?>" class="panel-collapse collapse in">
										  <div class="panel-body">
											<span class="answer">Answer</span>
												<?php $text = $faq['answer'] ;
													$pattern = "/<p[^>]*><\\/p[^>]*>/"; 
													//$pattern = "/<[^\/>]*>([\s]?)*<\/[^>]*>/";  use this pattern to remove any empty tag

													echo preg_replace($pattern, '', $text); 
												?>
											</div>
									</div>
								</div>
								<?php
									endforeach;
							endif;
							?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<style>
	.colored {
    color: #ffdc12;
	display: inline-block;
}
.display {
    display: inline-block;
}
.haide{ display: none; }
</style>



