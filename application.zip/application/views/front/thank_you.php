<section class="midd_content">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="step_tagline">
					<p>See If You Qualify for Debt Relief-Legally Resolve Most of the Debt You Owe.</p>
				</div>
			</div>
		</div>
		<div class="row quatation_form">
			<div class="col-md-8">
				<section class="quoteForm">
					<div class="content1">
					   <div class="pagesLinks"></div>
					   <section class="confirmation text-center">
						  <h1 class="mb-0">Thank You</h1>
						  <h2 class="mb-4">You Qualify for our Debt&nbsp;Relief Program</h2>
						  <h3 class="mb-4">NEXT STEP: A <u>debt&nbsp;relief&nbsp;expert</u> will contact you</h3>
						  <h4 class="mb-4 blue"><em><strong>Connect with them and learn how to:</strong></em></h4>
						  <ul class="benefits">
							 <li>Resolve your debt faster.</li>
							 <li>Significantly reduce what you owe.</li>
							 <li>Help you make one low monthly program payment.</li>
							 <li>End the guilt and worry.</li>
						  </ul>
						 
						  <!--
							 <img src="img/logo-helpcenter.png" alt="The Help Center" width="200">
							 -->        
						  <!--
							 <img src="img/logo-creditguard.png" alt="Credit Guard" width="200">    
							 -->        
					   </section>
					   <!--End quotes-->
					</div>
					
			    </section>
				<section class="subForm">
				  <p>Connect with a Debt Relief Expert Now. • "Say Goodbye" to Heavy Credit Card &amp; Medical Debt</p>
				  <div class="security">
					 <img src="<?php echo base_url('assets/front/') ?>images/bbb-icon.gif"> <span>BBB Accredited Business</span>
					 <br>
					 <img src="<?php echo base_url('assets/front/') ?>images/lock-icon.gif" class="pageBreak"> <span>Privacy Protected</span>
				  </div>
			   </section>
			</div> 
			<div class="col-md-4">
				<a href="tel:+18554974999"><img src="<?php echo base_url('assets/front/images/thank_you_banner.png')?>"></a>
			</div>
		</div>
	</div>
</section>

<style>
	.colored {
    color: #ffdc12;
}
.display {
    display: inline-block;
}
.haide{ display: none; }
.subForm {
    margin: 10px 0 30px 0;
    text-align: center;
}
</style>



